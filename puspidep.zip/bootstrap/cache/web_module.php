<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Web\\Providers\\WebServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Web\\Providers\\WebServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);