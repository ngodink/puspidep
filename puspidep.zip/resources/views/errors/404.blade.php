@extends('errors::default')

@section('title', __('Halaman tidak ditemukan - '))
@section('code', '404')
@section('message', __('Halaman yang Anda cari tidak ada, kemungkinan sudah dihapus atau rusak.'))
