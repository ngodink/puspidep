<?php 

Route::get('districts', 'API\ReferenceController@districts')->name('api.districts');
