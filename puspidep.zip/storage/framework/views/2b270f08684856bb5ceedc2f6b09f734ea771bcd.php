<?php $__env->startSection('title', 'Masuk - '); ?>

<?php $__env->startSection('content'); ?>
	<h2>Masuk</h2>
	<p class="text-muted mb-4">Masukkan kredensial Anda di bawah ini</p>
	<?php if(request('next')): ?>
		<p class="text-danger mb-4">Silahkan masuk untuk melanjutkan</p>
	<?php endif; ?>
	<form class="form-block" action="<?php echo e(route('account::auth.login', ['next' => request('next')])); ?>" method="POST"> <?php echo csrf_field(); ?>
		<div class="form-group">
			<input type="text" class="form-control" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>" <?php if(!old('username')): ?> autofocus <?php endif; ?> required autocomplete="off">
		</div>
		<div class="form-group">
			<div class="input-group">
				<input type="password" class="form-control" name="password" placeholder="Sandi" <?php if(old('username')): ?> autofocus <?php endif; ?> required autocomplete="off">
				<div class="input-group-append">
					<button type="button" class="btn btn-outline-secondary" id="toggle" tabindex="-1"><i id="toggle-icon" class="mdi mdi-eye"></i></button>
				</div>
			</div>
		</div>
		<div class="form-group">
			<div class="custom-control custom-checkbox">
				<input type="checkbox" class="custom-control-input" id="remember" name="remember" value="1" <?php if(old('remember')): ?> checked <?php endif; ?>>
				<label class="custom-control-label" for="remember">Ingat saya</label>
			</div>
		</div>
		<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<p class="text-danger"><?php echo e($message); ?></p>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<div class="form-group mb-0 mt-5">
			<button type="submit" class="btn btn-success px-3">Masuk</button>
			<a class="btn btn-link float-right pr-0" href="<?php echo e(route('account::auth.forgot')); ?>">Lupa sandi?</a>
		</div>
	</form>
	<p class="text-muted mt-5 mb-0">Tidak punya akun? <a href="<?php echo e(route('account::auth.register', ['next' => request('next')])); ?>">Buat akun</a></p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
	var toggle = false;
	$('#toggle').click(() => {
		toggle = !toggle;
		$('[name="password"]').attr('type', toggle ? 'text' : 'password');
		$('#toggle-icon').attr('class', toggle ? 'mdi mdi-eye-off' : 'mdi mdi-eye');
	})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('account::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Account\Resources/views/auth/login.blade.php ENDPATH**/ ?>