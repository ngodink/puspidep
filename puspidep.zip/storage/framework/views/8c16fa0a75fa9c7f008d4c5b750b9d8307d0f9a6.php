<?php $__env->startSection('titleTemplate', config('web.name')); ?>

<?php $__env->startSection('bodyclass', 'bg-light'); ?>

<?php $__env->startSection('main'); ?>
    <?php echo $__env->make('web::layouts.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="app" class="page-fade">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php echo $__env->make('account::auth.includes.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Web\Resources/views/layouts/default.blade.php ENDPATH**/ ?>