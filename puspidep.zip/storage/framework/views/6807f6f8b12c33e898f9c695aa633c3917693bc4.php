<?php $__env->startSection('content'); ?>
<div class="container py-4 bg-white rounded">
	<div class="row">
		<div class="col-md-8">
			<?php echo $__env->make('web::includes.post-widgets-4', ['posts' => $latest_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="card-columns" style="column-count: 2;">
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php ($posts = $category->load(['posts' => function($q) { return $q->take(6); }])->posts); ?>
					<div class="card bg-light border-0">
						<div class="card-body">
							<p><a class="text-muted" href="<?php echo e(route('web::category', ['category' => $category->slug])); ?>"><strong><?php echo e($category->name); ?></strong></a></p>
							<?php echo $__env->make('web::includes.post-widgets-3', ['posts' => $posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<?php if($posts->count()): ?>
								<a href="<?php echo e(route('web::category', ['category' => $category->slug])); ?>"><small>Lebih banyak &raquo;</small></a>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			
		</div>
		<div class="col-md-4">
			<h5 class="mb-3"><strong>Populer</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-1', ['posts' => $popular_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<hr class="my-4">
			<h5 class="mb-3"><strong>Postingan terbaru</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-2', ['posts' => $latest_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/index.blade.php ENDPATH**/ ?>