<?php $__env->startSection('title', $user->profile->name.' - '); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-center mb-4">
		<h3 class="mb-1">Info pribadi</h3>
		<p class="mb-0 text-muted">Info dasar, seperti nama dan foto, yang Anda gunakan di layanan kami</p>
	</div>
	<?php if($user->email->address && !$user->email->verified_at && $user->id == auth()->id()): ?>
		<div class="alert alert-danger">
			E-mail Anda belum terverifikasi, silahkan <a class="alert-link content-block" href="<?php echo e(route('account::user.email.reverify', ['uid' => encrypt($user->email->id), 'next' => ($next ?? route('account::index'))])); ?>">Klik disini!</a> untuk memverifikasi e-mail Anda!
		</div>
	<?php endif; ?>
	<div class="row">
		<div class="col-sm-5 col-md-4">
			<div class="card mb-4">
				<div class="dropdown position-absolute" style="top: .3em; right: 0;">
					<a class="btn btn-link text-secondary" href="javascript:;" id="dropdown" data-toggle="dropdown"><i class="mdi mdi-dots-vertical mdi-24px"></i></a>
					<div class="dropdown-menu dropdown-menu-right border-0 shadow">
						<?php if($user->phone->whatsapp): ?>
							<a class="dropdown-item" href="https://wa.me/<?php echo e($user->phone->number); ?>" target="_blank"><i class="mdi mdi-whatsapp"></i> Hubungi via Whatsapp</a>
						<?php endif; ?>
						<?php if($user->email->verified_at): ?>
							<a class="dropdown-item" href="mailto:<?php echo e($user->email->address); ?>"><i class="mdi mdi-email-outline"></i> Kirim e-mail</a>
						<?php endif; ?>
						<?php if(auth()->id() == $user->id): ?>
							<a class="dropdown-item" href="<?php echo e(route('account::auth.logout')); ?>" onclick="event.preventDefault(); $('#logout-form').submit();"><i class="mdi mdi-logout"></i> Keluar</a>
						<?php endif; ?>
					</div>
				</div>
				<div class="card-body text-center">
					<div class="py-4">
						<img class="rounded-circle" src="<?php echo e(asset('img/default-avatar.svg')); ?>" alt="" width="128">
					</div>
					<h5 class="mb-1"><strong><?php echo e($user->profile->name); ?></strong></h5>
					<p><?php echo e($user->username); ?></p>
					<h4 class="mb-0">
						<?php if($user->phone->whatsapp): ?>
							<a class="text-success px-1" href="https://wa.me/<?php echo e($user->phone->number); ?>" target="_blank"><i class="mdi mdi-whatsapp"></i></a>
						<?php endif; ?>
						<?php if($user->email->verified_at): ?>
							<a class="text-danger px-1" href="mailto:<?php echo e($user->email->address); ?>"><i class="mdi mdi-email-outline"></i></a>
						<?php endif; ?>
					</h4>
				</div>
			</div>
			<div class="card mb-4">
				<div class="card-body">
					<h4 class="mb-1">Info akun</h4>
					<p class="mb-2 text-muted">Informasi tentang akun Anda, hanya Anda yang dapat melihat ini</p>
				</div>
				<div class="list-group list-group-flush">
					<?php $__currentLoopData = [
						'Bergabung pada' => $user->created_at->diffForHumans(),
					]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="list-group-item border-0">
							<?php echo e($k); ?> <br>
							<span class="<?php echo e($v ? 'font-weight-bold' : 'text-muted'); ?>">
								<?php echo e($v ?? 'Belum diisi'); ?>

							</span>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="list-group-item border-0 text-muted">
						<i class="mdi mdi-account-circle"></i> User ID : <?php echo e($user->id); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="col-sm-7 col-md-8">
			<div class="card mb-4">
				<div class="dropdown position-absolute" style="top: .3em; right: 0;">
					<a class="btn btn-link text-secondary" href="javascript:;" id="dropdown" data-toggle="dropdown"><i class="mdi mdi-dots-vertical mdi-24px"></i></a>
					<div class="dropdown-menu dropdown-menu-right border-0 shadow">
						<a class="dropdown-item disabled" href="javascript:;"><i class="mdi mdi-image-edit-outline"></i> Ubah foto</a>
						<a class="dropdown-item" href="<?php echo e(route('account::user.profile')); ?>"><i class="mdi mdi-pencil-outline"></i> Ubah profil</a>
					</div>
				</div>
				<div class="card-body">
					<h4 class="mb-1">Profil</h4>
					<p class="mb-2 text-muted">Beberapa info mungkin terlihat oleh orang lain</p>
				</div>
				<div class="list-group list-group-flush">
					<?php $__currentLoopData = [
						'Nama lengkap' => [$user->profile->full_name, route('account::user.profile')],
						'Tempat lahir' => [$user->profile->pob, route('account::user.profile')],
						'Tanggal lahir' => [$user->profile->dob_name, route('account::user.profile')],
						'Jenis kelamin' => [$user->profile->sex_name, route('account::user.profile')],
					]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="list-group-item list-group-item-action border-0" href="<?php echo e($v[1]); ?>">
							<div class="row">
								<div class="col-10">
									<div class="row">
										<div class="col-md-4">
											<small><?php echo e($k); ?></small>
										</div>
										<div class="col-md-8">
											<span class="<?php echo e($v[0] ? 'font-weight-bold text-gray-800' : 'text-muted'); ?>">
												<?php echo e($v[0] ?? 'Belum diisi'); ?>

											</span>
										</div>
									</div>
								</div>
								<div class="col-2 text-right align-self-center">
									<i class="mdi mdi-chevron-right"></i>
								</div>
							</div>
						</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="card mb-4">
				<div class="card-body">
					<h4 class="mb-1">Info kontak</h4>
				</div>
				<div class="list-group list-group-flush">
					<?php $__currentLoopData = [
						'Alamat e-mail' => [$user->email->address, ($user->email->verified_at ? ' <span class="badge badge-pill badge-success font-weight-normal">Terverifikasi</span>' : ' <span class="badge badge-pill badge-danger font-weight-normal">Belum verifikasi</span>'), route('account::user.email')],
						'Nomor HP' => [$user->phone->number, ($user->phone->whatsapp ? ' <i class="mdi mdi-whatsapp text-success"></i>' : null), route('account::user.phone')],
					]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="list-group-item list-group-item-action border-0" href="<?php echo e($v[2]); ?>">
							<div class="row">
								<div class="col-10">
									<div class="row">
										<div class="col-md-4">
											<small><?php echo e($k); ?></small>
										</div>
										<div class="col-md-8">
											<span class="<?php echo e($v[0] ? 'font-weight-bold text-gray-800' : 'text-muted'); ?>">
												<?php echo $v[0] ? $v[0].$v[1] : 'Belum diisi'; ?>

											</span>
										</div>
									</div>
								</div>
								<div class="col-2 text-right align-self-center">
									<i class="mdi mdi-chevron-right"></i>
								</div>
							</div>
						</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="card mb-4">
				<div class="card-body">
					<i class="mdi mdi-settings-outline"></i> Menu lainnya 
				</div>
				<div class="list-group list-group-flush">
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('updateUsername', User::class)): ?>
						<a class="list-group-item list-group-item-action text-warning border-0" href="<?php echo e(route('account::username')); ?>"><i class="mdi mdi-pencil-outline"></i> Ubah username</a>
					<?php endif; ?>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
						<a class="list-group-item list-group-item-action text-warning border-0" href="<?php echo e(route('account::password')); ?>"><i class="mdi mdi-pencil-outline"></i> Ubah sandi</a>
					<?php endif; ?>
					<a class="list-group-item list-group-item-action text-warning" href="<?php echo e(route('account::auth.logout')); ?>" onclick="event.preventDefault(); $('#logout-form').submit();"><i class="mdi mdi-logout"></i> Keluar </a>
				</div>
			</div>
		</div>
	</div>
	<p class="text-center text-secondary mt-4 mb-0">Hanya Anda yang dapat mengakses halaman ini, kami berkomitmen untuk menjaga privasi Anda.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/index.blade.php ENDPATH**/ ?>