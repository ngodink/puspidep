<?php $__env->startSection('title', $category->name.' - '); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 bg-white rounded">

	<div class="row">
		<div class="col-md-8">
			<h5 class="mb-5"><strong><?php echo e($category->name); ?> terbaru</strong></h5>
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<a class="text-dark" href="<?php echo e(route('web::read', ['category' => $category->slug, 'slug' => $post->slug])); ?>">
					<div class="d-sm-flex flex-row filtered align-items-center">
						<div class="mr-sm-4">
							<div class="filtered-img mb-3 mb-sm-0 rounded" style="background: url(<?php echo e(asset('storage/'.$post->img)); ?>) center center no-repeat; background-size: cover; min-width: 200px; height: 200px;"></div>
						</div>
						<div class="my-3">
							<div class="d-flex flex-row align-items-center">
								<img class="rounded-circle mr-3" src="<?php echo e($post->author ? $post->author->profile->avatar_path : asset('img/default-avatar.svg')); ?>" alt="" style="width: 46px">
								<div>
									<div class="font-weight-bold"><?php echo e($post->author->profile->name ?? 'Penulis'); ?></div>
									<div class="text-muted small"><?php echo e($post->published_at->ISOFormat('LL')); ?></div>
								</div>
							</div>
							<h5 class="mt-3"><strong><?php echo e($post->title); ?></strong></h5>
							<div class="text-muted mb-2 mb-lg-4"><?php echo e(\Str::words(strip_tags($post->content), 12)); ?></div>
							<a href="<?php echo e(route('web::read', ['category' => $category->slug, 'slug' => $post->slug])); ?>">Selengkapnya &raquo;</a>
						</div>
					</div>
				</a>
				<?php if($loop->last): ?>
					<br><br>
					<?php echo e($posts->links()); ?>

				<?php else: ?>
					<hr class="my-4 my-sm-5">
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				Tidak ada <?php echo e(strtolower($category->name)); ?>

			<?php endif; ?>
		</div>
		<div class="col-md-4">
			<h5 class="mb-3"><strong>Populer</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-1', ['posts' => $popular_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<hr class="my-4">
			<h5 class="mb-3"><strong>Postingan terbaru</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-2', ['posts' => $latest_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/category.blade.php ENDPATH**/ ?>