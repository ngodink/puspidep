<?php $__env->startSection('title', $post->title.' - '); ?>

<?php $__env->startSection('meta_description', Str::words(strip_tags($post->content), 15)); ?>
<?php $__env->startSection('meta_image', $post->img ? Storage::url($post->img) : null); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 bg-white rounded">
	<div class="row">
		<div class="col-md-8">
			<div class="card mb-4 border-0">
				<?php if($post->img): ?>
					<img src="<?php echo e(Storage::url($post->img)); ?>" class="card-img-top rounded" alt="">
				<?php else: ?>
					<div class="card-body bg-light rounded" style="height: 18vh;"></div>
				<?php endif; ?>
				<div class="card-body p-2 p-sm-4">
					<div class="p-4 bg-white rounded shadow" style="margin-top: -18%;">
						<p>
							<?php $__empty_1 = true; $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<span class="badge badge-pill badge-dark"><?php echo e($category->name); ?></span>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<span class="badge badge-pill badge-secondary">Uncategorized</span>
							<?php endif; ?>
						</p>
						<h2 class="mb-2"><strong><?php echo e($post->title); ?></strong></h2>
						<div class="text-muted mb-4">
							<i class="mdi mdi-eye"></i> <small><?php echo e($post->views_count); ?></small>
							
							<i class="mdi <?php echo e($post->commentable ? 'mdi-comment' : 'mdi-comment-remove'); ?>"></i> <small><?php echo e($post->comments_count); ?></small>
							<i class="mdi mdi-calendar"></i> <small><?php echo e($post->created_at ? $post->created_at->ISOFormat('L') : '-'); ?></small>
						</div>
						<div class="d-flex flex-row align-items-center">
							<img class="rounded-circle mr-3" src="<?php echo e($post->author ? $post->author->profile->avatar_path : asset('img/default-avatar.svg')); ?>" alt="" style="width: 46px">
							<div>
								<div class="font-weight-bold"><?php echo e($post->author->profile->name ?? 'Penulis'); ?></div>
								<i><?php echo e($post->author->profile->bio ?? 'Tidak ada bio'); ?></i>
							</div>
						</div>
						<div class="mt-4">
							<?php echo $post->content; ?>

						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<h5 class="mb-3"><strong>Postingan terkait</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-1', ['posts' => $related_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<hr class="my-4">
			<h5 class="mb-3"><strong>Postingan terbaru</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-2', ['posts' => $latest_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<hr class="my-4">
			<h5 class="mb-3"><strong>Populer</strong></h5>
			<?php echo $__env->make('web::includes.post-widgets-3', ['posts' => $popular_posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/read.blade.php ENDPATH**/ ?>