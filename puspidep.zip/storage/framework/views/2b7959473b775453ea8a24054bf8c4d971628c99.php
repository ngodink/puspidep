<?php $__env->startSection('titleTemplate', config('app.name').' - Pusat Pengkajian Islam Demokrasi dan Perdamaian'); ?>

<?php $__env->startSection('bodyclass', 'min-vh-100 d-flex flex-column justify-content-between bg-light'); ?>

<?php $__env->startSection('main'); ?>
    
    <div id="wrapper">
        <?php echo $__env->make('web::layouts.includes.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <button id="sidebarToggleTop" class="btn btn-light text-dark d-md-none rounded-circle m-2 position-fixed" style="right: 0; z-index: 99;">
                    <i class="mdi mdi-menu mdi-24px"></i>
                </button>
                <div class="container-fluid pt-4">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert"> <span>&times;</span> </button>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('danger')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('danger')); ?>

                            <button type="button" class="close" data-dismiss="alert"> <span>&times;</span> </button>
                        </div>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <?php echo $__env->make('web::layouts.includes.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('account::auth.includes.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/layouts/admin.blade.php ENDPATH**/ ?>