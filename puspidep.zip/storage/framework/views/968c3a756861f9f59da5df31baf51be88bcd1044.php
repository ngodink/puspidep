<?php $__env->startSection('bodyclass', 'd-flex min-vh-100 align-items-center text-center bg-white'); ?>

<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <p><img src="<?php echo e(asset('img/undraw/empty.png')); ?>" alt="" class="w-100" style="max-width: 400px;"></p>
        <div class="display-4 font-weight-bold mb-2">
            <?php echo $__env->yieldContent('code'); ?>
        </div>
        <p class="text-muted"><?php echo $__env->yieldContent('message'); ?></p>
        <a class="btn btn-sm btn-dark rounded-pill px-3 mr-2" href="<?php echo e(url()->previous()); ?>">Kembali</a>
        <a class="btn btn-sm btn-outline-dark rounded-pill px-3" href="<?php echo e(config('app.url')); ?>">Halaman utama</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\resources\views/errors/minimal.blade.php ENDPATH**/ ?>