<div class="form-group required">
	<label>Nomor HP</label>
	<input type="number" class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="number" value="<?php echo e(old('number', $user->phone->number ?? 62)); ?>" required data-mask="62#">
	<small class="form-text text-muted">Ditulis menggunakan kode negara, misal 085123xxxxx menjadi 6285123xxxxx (tanpa tanda plus).</small>
	<?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<small class="text-danger"> <?php echo e($message); ?> </small>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
	<div class="custom-control custom-checkbox">
		<input class="custom-control-input" type="checkbox" id="whatsapp" value="1" name="whatsapp" <?php if($user->phone->whatsapp): ?> checked <?php endif; ?>>
		<label class="custom-control-label" for="whatsapp">Nomor ini <strong><span id="whatsapp-text"><?php if(!$user->phone->whatsapp): ?> tidak <?php endif; ?></span> terdaftar</strong> di whatsapp</label>
	</div>
</div>
<div class="form-group mb-0">
	<button class="btn btn-warning" type="submit">Simpan</button>
	<?php if(isset($back)): ?>
		<a class="btn btn-secondary" href="<?php echo e(request('next', route('account::index'))); ?>">Kembali</a>
	<?php endif; ?>
</div><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/phone/includes/form.blade.php ENDPATH**/ ?>