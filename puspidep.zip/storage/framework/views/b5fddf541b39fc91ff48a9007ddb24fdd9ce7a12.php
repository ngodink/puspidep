<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('administration.name'); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administration::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Administration\Resources/views/index.blade.php ENDPATH**/ ?>