<?php $__env->startSection('title', __('Halaman tidak ditemukan - ')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Halaman yang Anda cari tidak ada, kemungkinan sudah dihapus atau rusak.')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\resources\views/errors/404.blade.php ENDPATH**/ ?>