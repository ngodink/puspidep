<?php $__env->startSection('title', 'Ubah sandi - '); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
	<div class="col-sm-10 col-md-8 col-lg-6">
		<h2>
			<a class="text-decoration-none small" href="<?php echo e(request('next', route('account::index'))); ?>"><i class="mdi mdi-arrow-left-circle-outline"></i></a>
			Ubah sandi
		</h2>
		<hr>
		<p class="text-secondary">Pilih sandi yang kuat dan jangan gunakan lagi untuk akun lain</p>
		<div class="card mb-4">
			<div class="card-body">
				<form class="form-block" action="<?php echo e(route('account::password', ['next' => request('next')])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
					<div class="form-group required">
						<label>Sandi lama</label>
						<input type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="old_password" required autofocus>
						<?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<small class="text-danger"> <?php echo e($message); ?> </small>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group required">
						<label>Sandi baru</label>
						<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required>
						<small class="form-text text-muted">Gunakan sedikitnya 4 karakter. Jangan gunakan sandi dari situs lain atau sesuatu yang mudah ditebak seperti tanggal lahir Anda.</small>
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<small class="text-danger"> <?php echo e($message); ?> </small>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group required">
						<label>Konfirmasi sandi baru</label>
						<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" required>
					</div>
					<div class="form-group mb-0">
						<button class="btn btn-warning" type="submit">Simpan</button>
						<a class="btn btn-secondary" href="<?php echo e(request('next', route('account::index'))); ?>">Kembali</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/password.blade.php ENDPATH**/ ?>