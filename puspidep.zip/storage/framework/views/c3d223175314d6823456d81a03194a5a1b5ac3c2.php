<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="row text-muted small">
			<div class="col-sm-6 text-center text-sm-left">
				Copyright © 2020
			</div>
			<div class="col-sm-6 text-center text-sm-right">
				All rights reserved to <?php echo e(config('app.name')); ?>

			</div>
		</div>
	</div>
</footer><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/layouts/includes/admin/footer.blade.php ENDPATH**/ ?>