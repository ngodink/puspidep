

<?php $__env->startSection('bodyclass', 'bg-gradient-warning min-vh-100 d-flex align-items-center'); ?>

<?php $__env->startSection('main'); ?>
    
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('account::auth.includes.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Member\Resources/views/layouts/registration.blade.php ENDPATH**/ ?>