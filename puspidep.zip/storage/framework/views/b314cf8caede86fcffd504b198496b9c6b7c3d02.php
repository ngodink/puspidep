<?php $__env->startSection('title', 'Ubah nomor HP - '); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
	<div class="col-sm-10 col-md-8 col-lg-6">
		<h2>
			<a class="text-decoration-none small" href="<?php echo e(request('next', route('account::index'))); ?>"><i class="mdi mdi-arrow-left-circle-outline"></i></a>
			Ubah nomor HP
		</h2>
		<hr>
		<p class="text-secondary">Nomor HP ini digunakan untuk menerima notifikasi dari sistem.</p>
		<div class="card mb-4">
			<div class="card-body">
				<form class="form-block" action="<?php echo e(route('account::user.phone', ['next' => request('next')])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
					<?php echo $__env->make('account::user.phone.includes.form', ['user' => $user, 'back' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
	<script>
		$('#whatsapp').on('change', (e) => {
		    $('#whatsapp-text').text($(e.target).is(':checked') ? '' : 'tidak')
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('account::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/phone/edit.blade.php ENDPATH**/ ?>