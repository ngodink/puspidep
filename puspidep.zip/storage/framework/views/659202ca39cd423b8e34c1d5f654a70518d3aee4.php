<?php $__env->startSection('titleTemplate', config('account.name')); ?>

<?php $__env->startSection('bodyclass', 'bg-light'); ?>

<?php $__env->startSection('main'); ?>
    <?php echo $__env->make('account::layouts.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(session('success')): ?>
	<div class="alert alert-success bg-success text-white rounded-0 border-0 px-0 mb-0">
		<div class="container">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
			<?php echo session('success'); ?>

		</div>
	</div>
	<?php endif; ?>
	<?php if(session('danger')): ?>
	<div class="alert alert-danger bg-danger text-white rounded-0 border-0 px-0 mb-0">
		<div class="container">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
			<?php echo session('danger'); ?>

		</div>
	</div>
	<?php endif; ?>
	<div id="app" class="py-3 py-sm-4 page-fade">
		<main>
			<div class="container">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</main>
	</div>
    <?php echo $__env->make('account::auth.includes.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Account\Resources/views/layouts/default.blade.php ENDPATH**/ ?>