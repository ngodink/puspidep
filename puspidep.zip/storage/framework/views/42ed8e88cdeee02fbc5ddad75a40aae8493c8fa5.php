<?php $__env->startSection('title', 'Ubah username - '); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
	<div class="col-sm-10 col-md-8 col-lg-6">
		<h2>
			<a class="text-decoration-none small" href="<?php echo e(request('next', route('account::index'))); ?>"><i class="mdi mdi-arrow-left-circle-outline"></i></a>
			Ubah username
		</h2>
		<hr>
		<p class="text-secondary">Username ini digunakan untuk login ke <?php echo e(config('app.name')); ?></p>
		<div class="card mb-4">
			<div class="card-body">
				<form class="form-block" action="<?php echo e(route('account::username', ['next' => request('next')])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
					<div class="form-group required">
						<label>Username</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text">@</span>
							</div>
							<input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username', $user->username)); ?>" required>
						</div>
						<small class="form-text text-muted">Nama unik pengguna (bukan nama lengkap), digunakan untuk login, terdiri dari huruf kecil, titik, dan angka, tanpa spasi.</small>
						<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<small class="text-danger"> <?php echo e($message); ?> </small>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group mb-0">
						<button class="btn btn-warning" type="submit">Simpan</button>
						<a class="btn btn-secondary" href="<?php echo e(request('next', route('account::index'))); ?>">Kembali</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/username.blade.php ENDPATH**/ ?>