

<?php $__env->startSection('title', 'Registrasi Anggota Baru - '); ?>

<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center py-4">
		<div class="col-sm-10 col-md-8 col-lg-6">
			<div class="card">
				<?php if(request('next')): ?>
					<div class="card-header px-sm-5 py-sm-3 text-danger">
						<strong>Anda belum terdaftar!</strong> <br>
						Silahkan lakukan pendaftaran terlebih dahulu!
					</div>
				<?php endif; ?>
				<div class="card-body px-sm-5 py-sm-4">
					<h4><strong>Bergabung bersama kami</strong></h4>
					<p class="text-muted"><?php echo e(config('app.name')); ?></p>
					<?php if(session('success')): ?>
					    <div class="text-success">
				            <?php echo session('success'); ?>

					    </div>
					<?php endif; ?>
					<?php if(session('danger')): ?>
					    <div class="text-danger">
				            <?php echo session('danger'); ?>

					    </div>
					<?php endif; ?>
					<hr>
					<?php if(empty($type)): ?>
						<h5><strong>Pilih jenis keanggotaan</strong></h5>
						<p>Apa yang ingin anda daftarkan?</p>
						<form class="form-block" action="<?php echo e(route('member::register')); ?>">
							<input type="hidden" name="next" value="<?php echo e(request('next', route('member::index'))); ?>">
							<input type="hidden" name="type" value="individu">
							<div class="form-group">
								<button class="btn btn-outline-warning rounded-pill"><i class="mdi mdi-chevron-right-circle-outline"></i> Saya ingin mendaftar sebagai anggota individu</button>
							</div>
						</form>
						<form class="form-block" action="<?php echo e(route('member::register')); ?>">
							<input type="hidden" name="next" value="<?php echo e(request('next', route('member::index'))); ?>">
							<input type="hidden" name="type" value="lembaga">
							<div class="form-group">
								<button class="btn btn-outline-warning rounded-pill"><i class="mdi mdi-chevron-right-circle-outline"></i> Saya ingin mendaftarkan lembaga saya</button>
							</div>
						</form>
						<p><a href="#">Klik disini</a> untuk melihat tutorial pendaftaran.</p>
						<hr>
						<a class="btn btn-secondary" href="<?php echo e(route('web::index')); ?>">Kembali</a>
					<?php else: ?>
						<form class="form-block form-confirm" action="<?php echo e(route('member::register')); ?>" method="post"> <?php echo csrf_field(); ?>
							<div class="form-group required">
								<label>No kepegawaian</label>
								<input class="form-control <?php $__errorArgs = ['employee_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="employee_number" value="<?php echo e(old('employee_number')); ?>" autofocus required>
								<small class="form-text text-muted">Diisi NIDN/NIP Anda atau nomor identitas kelembagaan/kepegawaian lainnya.</small>
								<?php $__errorArgs = ['employee_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
									<small class="text-danger"> <?php echo e($message); ?></small> 
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<?php if($type == 'lembaga'): ?>
								<div class="form-group required">
									<label>Nama lembaga</label>
									<input class="form-control <?php $__errorArgs = ['instance_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="instance_name" value="<?php echo e(old('instance_name')); ?>" required>
									<small class="form-text text-muted">Nama Lembaga yang ingin Anda daftarkan sesuai SK Pendirian Prodi/Lembaga</small>
									<?php $__errorArgs = ['instance_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
										<small class="text-danger"> <?php echo e($message); ?></small> 
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class="form-group required">
									<label>Alamat lembaga</label>
									<select class="form-control <?php $__errorArgs = ['instance_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="instance_address" required>
									    <?php if(old('instance_address')): ?>
									        <?php
									            $district = \App\Models\References\ProvinceRegencyDistrict::with('regency.province')->find(old('instance_address'));
									        ?>
									        <option value="<?php echo e($district->id); ?>"><?php echo e($district->regional); ?></option>
									    <?php endif; ?>
									</select>
									<?php $__errorArgs = ['instance_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
										<small class="invalid-feedback"> <?php echo e($message); ?></small> 
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							<?php endif; ?>
							<hr>
							<p><small class="text-muted">Dengan menekan tombol "Daftar!" maka saya sebagai pendaftar menyetujui segala ketentuan dan persyaratan sesuai mekanisme pendaftaran.</small></p>
							<div class="d-flex flex-row justify-content-between">
								<a class="btn btn-secondary" href="<?php echo e(url()->previous()); ?>">Sebelumnya</a>
								<button type="submit" class="btn btn-warning">Daftar!</button>
							</div>
						</form>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script>
        $(() => {
            $('[name="instance_address"]').select2({
                placeholder: 'Cari nama kecamatan disini, misal "BANTUL" ...',
                ajax: {
                    delay: 1000,
                    url: '<?php echo e(route('api.districts')); ?>',
                    dataType: 'json',
                    processResults: function (data, params) {
                        return {
                            results: data
                        }
                    }
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('member::layouts.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Member\Resources/views/register.blade.php ENDPATH**/ ?>