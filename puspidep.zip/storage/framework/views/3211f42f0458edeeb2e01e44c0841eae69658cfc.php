<?php $__env->startSection('title', 'Ubah profil - '); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
	<div class="col-sm-10 col-md-9 col-lg-8">
		<h2>
			<a class="text-decoration-none small" href="<?php echo e(request('next', route('account::index'))); ?>"><i class="mdi mdi-arrow-left-circle-outline"></i></a>
			Ubah profil
		</h2>
		<hr>
		<p class="text-secondary">Perubahan informasi dibawah akan diterapkan di <?php echo e(config('app.name')); ?> Anda</p>
		<div class="card mb-4">
			<div class="card-body">
				<form class="form-block" action="<?php echo e(route('account::user.profile', ['next' => request('next')])); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
					<?php echo $__env->make('account::user.profile.includes.form', ['user' => $user, 'back' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/profile/edit.blade.php ENDPATH**/ ?>