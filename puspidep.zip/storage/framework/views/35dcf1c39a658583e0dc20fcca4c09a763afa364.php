<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <?php if(env('APP_DEBUG', false) == false): ?>
        <link href="https://fonts.googleapis.com/css?family=Muli&display=swap" rel="stylesheet">
    <?php endif; ?>
    <link href="<?php echo e(asset('vendor/mdi/css/materialdesignicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.min.css')); ?>" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?> <?php echo $__env->yieldContent('titleTemplate', config('app.name', 'Application')); ?></title>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body class="<?php echo $__env->yieldContent('bodyclass'); ?>">
    
    <?php echo $__env->yieldContent('main'); ?>

    <script src="<?php echo e(asset('js/script.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\aiat\resources\views/layouts/default.blade.php ENDPATH**/ ?>