<fieldset>
	<div class="row">
		<div class="col-md-7 offset-md-4 offset-lg-3">
			<h5 class="text-muted font-weight-normal mb-3">Informasi umum</h5>
		</div>
	</div>

	<div class="form-group row">
		<label class="col-md-4 col-lg-3 col-form-label">Gelar depan</label>
		<div class="col-md-4">
			<input type="prefix" class="form-control <?php $__errorArgs = ['prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prefix" value="<?php echo e(old('prefix', $user->profile->prefix)); ?>" >
			<?php $__errorArgs = ['prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group required row">
		<label class="col-md-4 col-lg-3 col-form-label">Nama lengkap</label>
		<div class="col-md-7">
			<input type="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="name" value="<?php echo e(old('name', $user->profile->name)); ?>" required>
			<small class="form-text text-muted">Nama lengkap (tidak boleh disingkat) diisi menggunakan huruf kapital sesuai Akta/KTP/KK atau identitas resmi lainnya.</small>
			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($messagae); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group row">
		<label class="col-md-4 col-lg-3 col-form-label">Gelar belakang</label>
		<div class="col-md-4">
			<input type="suffix" class="form-control <?php $__errorArgs = ['suffix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="suffix" value="<?php echo e(old('suffix', $user->profile->suffix)); ?>">
			<?php $__errorArgs = ['suffix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group required row">
		<label class="col-md-4 col-lg-3 col-form-label">Tempat lahir</label>
		<div class="col-md-5">
			<input type="pob" class="form-control <?php $__errorArgs = ['pob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pob" value="<?php echo e(old('pob', $user->profile->pob)); ?>" required>
			<small class="form-text text-muted">Nama lengkap diisi menggunakan huruf kapital sesuai Akta/KTP/KK atau identitas resmi lainnya.</small>
			<?php $__errorArgs = ['pob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group required row">
		<label class="col-md-4 col-lg-3 col-form-label">Tanggal lahir</label>
		<div class="col-md-5">
			<input type="date" class="form-control <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dob" value="<?php echo e(old('dob', $user->profile->dob ? $user->profile->dob->format('d-m-Y') : '')); ?>" required>
			<small class="form-text text-muted">Diisi dengan format hh-bb-tttt (ex: 23-02-2001) dan sesuai dengan Kartu Keluarga atau akta kelahiran </small>
			<?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group required row">
		<label class="col-md-4 col-lg-3 col-form-label">Jenis kelamin</label>
		<div class="col-md-4">
			<div class="btn-group btn-group-toggle" data-toggle="buttons">
				<?php $__currentLoopData = \Modules\Account\Models\UserProfile::$sex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<label class="btn btn-outline-secondary <?php if((!is_null($user->profile->sex)) && (old('sex', $user->profile->sex) == $k)): ?> active <?php endif; ?>">
					<input type="radio" name="sex" value="<?php echo e($k); ?>" required autocomplete="off" <?php if((!is_null($user->profile->sex)) && (old('sex', $user->profile->sex) == $k)): ?> checked <?php endif; ?>> <?php echo e($v); ?>

				</label>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<small class="text-danger"> <?php echo e($message); ?> </small>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>

	<div class="form-group row">
		<label class="col-md-4 col-lg-3 col-form-label">Golongan darah</label>
		<div class="col-md-4">
			<select name="blood" class="form-control <?php $__errorArgs = ['blood'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				<option value="">-- Pilih --</option>
				<?php $__currentLoopData = \Modules\Account\Models\UserProfile::$blood; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($k); ?>" <?php if((!is_null($user->profile->blood)) && (old('blood', $user->profile->blood) == $k)): ?> selected <?php endif; ?>><?php echo e($v); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php $__errorArgs = ['blood'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>
</fieldset>
<hr>
<fieldset>

	<div class="row">
		<div class="col-md-7 offset-md-4 offset-lg-3">
			<h5 class="text-muted font-weight-normal mb-3">Data kewarganegaraan</h5>
		</div>
	</div>
	<div class="form-group required row">
		<label class="col-md-4 col-lg-3 col-form-label">NIK</label>
		<div class="col-md-7">
			<input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik" value="<?php echo e(old('nik', $user->profile->nik)); ?>" required data-mask="0000000000000000">
			<small class="form-text text-muted">Nomor Induk Kependudukan, sesuai KTP/KK/Identitas resmi lainnya</small>
			<?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback"> <?php echo e($message); ?> </span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>
</fieldset>
<hr>
<div class="form-group row mb-0">
	<div class="col-md-7 offset-md-4 offset-lg-3">
		<button class="btn btn-warning" type="submit">Simpan</button>
		<?php if(isset($back)): ?>
			<a class="btn btn-secondary" href="<?php echo e(request('next', route('account::index'))); ?>">Kembali</a>
		<?php endif; ?>
	</div>
</div><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/profile/includes/form.blade.php ENDPATH**/ ?>