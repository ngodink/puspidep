<div class="navbar-expand py-3">
	<div class="container">
		<div class="d-sm-flex flex-row justify-content-sm-between align-items-center text-center">
			<div>
				<a class="navbar-brand text-dark py-3" href="<?php echo e(route('web::index')); ?>">
					<img class="pr-1" src="<?php echo e(asset('img/logo/rounded-bw-32.png')); ?>" alt="" style="margin-top: -5px;">
					<strong><?php echo e(config('app.name')); ?></strong>
				</a>
			</div>
			<div>
				<a class="text-dark mr-2" href="<?php echo e(route('web::about')); ?>"><small>Tentang kami</small></a>
				<a class="text-dark mr-2" href="https://www.facebook.com/puspidep.puspidep.9"><i class="mdi mdi-facebook"></i></a>
				<a class="text-dark mr-2" href="#"><i class="mdi mdi-twitter"></i></a>
				<a class="text-dark mr-2" href="https://www.instagram.com/puspidep"><i class="mdi mdi-instagram"></i></a>
				<?php if(auth()->guard()->check()): ?>
					<a class="text-dark mr-2" href="<?php echo e(route('web::admin.dashboard')); ?>"><small>Admin</small></a>
					<a class="text-dark" href="<?php echo e(route('account::auth.logout')); ?>" onclick="event.preventDefault(); $('#logout-form').submit();"><small>Logout</small></a>
				<?php else: ?>
					<a class="text-dark" href="<?php echo e(route('account::auth.login', ['next' => url()->current()])); ?>"><small>Login</small></a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<nav class="navbar navbar-expand navbar-dark bg-dark overflow-auto mb-4">
	<div class="container">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item text-nowrap">
				<a class="nav-link" href="<?php echo e(route('web::index')); ?>">
					<i class="mdi mdi-home-outline mdi-18px" style="line-height: 1.4rem;"></i>
				</a>
			</li>
			<?php $__currentLoopData = $BLOG_CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $__category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="nav-item text-nowrap">
					<a class="nav-link" href="<?php echo e(route('web::category', ['category' => $__category->slug])); ?>"><?php echo e($__category->name); ?></a>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
</nav><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/layouts/includes/navbar.blade.php ENDPATH**/ ?>