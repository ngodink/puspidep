

<?php $__env->startSection('title', 'Buat postingan baru - '); ?>

<?php ($url = url()->current()); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
	<h5 class="mb-0">
		<a href="<?php echo e(request('next', route('web::admin.posts.index'))); ?>"><i class="mdi mdi-arrow-left-circle-outline"></i></a>
		<strong>Buat postingan baru</strong>
	</h5>
</div>
<form class="form-block" action="<?php echo e(route('web::admin.posts.store')); ?>" method="POST" enctype="multipart/form-data" id="create_post"> <?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-lg-4">
			<div class="card border-0 mb-4">
				<div class="card-body">
					<div class="form-group">
						<label>Kategori</label>
						<div class="rounded border p-2">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input" name="categories[]" id="category<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>" <?php if(in_array($category->id, old('categories', []))): ?> checked <?php endif; ?>>
									<label class="custom-control-label" for="category<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<label>Penulis</label>
						<select type="text" class="form-control <?php $__errorArgs = ['author_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="author_id">
								<option value="">-- Pilih --</option>
						</select>
						<?php $__errorArgs = ['author_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<label>Waktu publish</label>
						<input type="date" class="form-control <?php $__errorArgs = ['published_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="published_at" value="<?php echo e(date('Y-m-d')); ?>">
						<?php $__errorArgs = ['published_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<label>Foto cover</label>
					<div class="border rounded text-center mb-3">
						<img id="upload-preview" class="img-fluid" src="<?php echo e(asset('img/no-image.png')); ?>" alt="" style="max-height: 224px;">
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="custom-file">
								<input type="file" name="file" class="custom-file-input" id="upload-input" accept="image/*">
								<label class="custom-file-label" for="upload-input">Pilih cover ...</label>
							</div>
						</div>
						<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<small class="text-danger"> <?php echo e($message); ?> </small>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-8 order-lg-first">
			<div class="card border-0 mb-4">
				<div class="card-body">
					<div class="form-group">
						<input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" placeholder="Judul postingan" value="<?php echo e(old('title')); ?>" autofocus required>
						<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<textarea name="content" class="summernote">
							<?php echo e(old('content')); ?>

						</textarea>
						<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" id="commentable" checked name="commentable" value="1">
							<label class="custom-control-label" for="commentable">Centang untuk mengaktifkan fitur komentar</label>
						</div>
					</div>
					<div class="form-group mb-0">
						<button type="submit" class="btn btn-success"><i class="mdi mdi-check"></i> Publish</button>
						<button type="button" class="btn btn-warning" id="save_as_draft"><i class="mdi mdi-content-save-outline"></i> Simpan sebagai draft</button>
						<a class="btn btn-secondary" href="<?php echo e(request('next', route('web::admin.posts.index'))); ?>"><i class="mdi mdi-arrow-left"></i> Kembali</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('js/summernote.min.js')); ?>"></script>
<script>
	$(() => {
		$('.summernote').summernote({
			placeholder: 'Tulis isi postingan disini ...',
			height: 250
		});
		$('#save_as_draft').click(() => {
			if (confirm('Apakah Anda yakin?')) {
				$('[name="published_at"]').val('')
				$('#create_post').submit();
			}
		});
		function readURL(input) {
			if (input.files && input.files[0]) {
				$('[for="upload-input"]').html(input.files[0].name)
				var reader = new FileReader();
				reader.onload = function(e) {
					$('#upload-preview').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}

		$("#upload-input").change(function(e) {
			readURL(this);
		});
	})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/admin/posts/create.blade.php ENDPATH**/ ?>