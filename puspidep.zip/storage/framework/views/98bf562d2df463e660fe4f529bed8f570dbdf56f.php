<?php $__env->startSection('bodyclass', 'min-vh-100 d-flex justify-content-center align-items-center'); ?>

<?php $__env->startSection('main'); ?>
<div class="container text-center">
	<div class="display-2 mb-4">500</div>
	<h4><strong>Mohon maaf!</strong></h4>
	<p class="text-muted">Website <strong><?php echo e(env('APP_URL')); ?></strong> sedang mengalami perbaikan, silahkan tunggu beberapa waktu kedepan.</p>
	<a class="btn btn-outline-dark rounded-pill" href="<?php echo e(route('member::index')); ?>">Situs keanggotaan</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Web\Resources/views/index.blade.php ENDPATH**/ ?>