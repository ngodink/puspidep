<div class="mb-4">
	<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<a class="text-dark" href="<?php echo e(route('web::read', ['category' => $post->category()->slug, 'slug' => $post->slug])); ?>">
			<div class="d-flex flex-row align-items-center justify-content-between mb-2">
				<div class="rounded mr-2" style="background: url(<?php echo e(asset('storage/'.$post->img)); ?>) center center no-repeat; background-size: cover; min-width: 60px; height: 60px;"></div>
				<div class="flex-grow-1">
					<strong><?php echo e(Str::limit($post->title, 50)); ?></strong> <br>
					<div class="text-muted">
						<i class="mdi mdi-eye"></i> <small><?php echo e($post->views_count); ?></small>
						
						<i class="mdi <?php echo e($post->commentable ? 'mdi-comment' : 'mdi-comment-remove'); ?>"></i> <small><?php echo e($post->comments_count); ?></small>
						<i class="mdi mdi-calendar"></i> <small><?php echo e($post->created_at ? $post->created_at->ISOFormat('L') : '-'); ?></small>
					</div>
				</div>
			</div>
		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		Tidak ada postingan
	<?php endif; ?>
</div><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/includes/post-widgets-1.blade.php ENDPATH**/ ?>