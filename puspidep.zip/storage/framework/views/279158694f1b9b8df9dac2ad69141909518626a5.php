<?php $__env->startSection('title', 'Contact us - '); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 bg-white rounded">
	<h5 class="mb-5"><strong>Get in touch</strong></h5>
	<div>
		<div class="d-flex flex-row align-items-center mb-5">
			<div class="bg-light rounded text-center px-4 py-2 mr-4">
				<i class="mdi mdi-email-outline mdi-48px"></i>
			</div>
			<div>
				<strong>E-mail</strong> <br>
				<a class="text-dark" href="mailto:puspidep@gmail.com">puspidep@gmail.com</a>
			</div>
		</div>
		<div class="d-flex flex-row align-items-center mb-5">
			<div class="bg-light rounded text-center px-4 py-2 mr-4">
				<i class="mdi mdi-phone-outline mdi-48px"></i>
			</div>
			<div>
				<strong>Telepon</strong> <br>
				<div>02744399482</div>
			</div>
		</div>
		<div class="d-flex flex-row align-items-center">
			<div class="bg-light rounded text-center px-4 py-2 mr-4">
				<i class="mdi mdi-home-outline mdi-48px"></i>
			</div>
			<div>
				<strong>Alamat</strong> <br>
				<div>Jl. Gurami No. 51 Kelurahan Sorosutan, Kecamatan Umbulharjo, Kota Yogyakarta, DIY.</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/contact.blade.php ENDPATH**/ ?>