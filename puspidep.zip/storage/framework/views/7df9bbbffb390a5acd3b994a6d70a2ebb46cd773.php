<div class="form-group required">
	<label>Alamat e-mail</label>
	<input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', $user->email->address)); ?>" required>
	<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<small class="text-danger"> <?php echo e($message); ?> </small>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php if($user->email->address): ?> 
	<div class="form-group">
		<div class="mb-1">Status verifikasi</div>
		<?php if($user->email->verified_at): ?> 
			<div class="text-warning"><i class="icon-check"></i> Terverifikasi</div>
		<?php else: ?>
			<div class="text-danger"><i class="icon-close"></i> Belum terverifikasi</div>
			<a class="content-block" href="<?php echo e(route('account::user.email.reverify', ['uid' => encrypt($user->email->id), 'next' => ($next ?? route('account::index'))])); ?>">Kirim tautan verifikasi sekarang!</a>
		<?php endif; ?>
	</div>
<?php endif; ?>
<div class="form-group mb-0">
	<button class="btn btn-warning" type="submit">Simpan</button>
	<?php if(isset($back)): ?>
		<a class="btn btn-secondary" href="<?php echo e(request('next', route('account::index'))); ?>">Kembali</a>
	<?php endif; ?>
</div>
<?php if($user->email->verified_at): ?>
<hr>
<p class="mb-0">
	<strong>Peringatan!</strong> <br>
	Jika Anda mengubah alamat e-mail <?php echo e($user->profile->display_name); ?>, kami akan melakukan verifikasi ulang terhadap e-mail tersebut
</p>
<?php endif; ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/email/includes/form.blade.php ENDPATH**/ ?>