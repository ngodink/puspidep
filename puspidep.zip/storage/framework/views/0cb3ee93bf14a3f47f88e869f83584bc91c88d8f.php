<?php $__env->startSection('title', 'Atur ulang sandi -'); ?>

<?php $__env->startSection('content'); ?>
	<h2>Atur ulang sandi</h2>
	<p class="text-muted mb-4">Harap ingat baik-baik sandi Anda!</p>
	<form class="form-block" action="<?php echo e(route('account::auth.broker')); ?>" method="POST"> <?php echo csrf_field(); ?>
		<input type="hidden" name="token" value="<?php echo e($token ?? ''); ?>">
		<div class="form-group">
			<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Sandi" required autofocus>
		</div>
		<div class="form-group">
			<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" placeholder="Ulangi sandi" required>
		</div>
		<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<p class="text-danger"><?php echo e($message); ?></p>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<p class="text-muted">Gunakan sedikitnya 8 karakter. Jangan gunakan sandi dari situs lain atau sesuatu yang mudah ditebak seperti tanggal lahir Anda.</p>
		<div class="form-group mb-0 mt-5">
			<button type="submit" class="btn btn-warning px-3">Simpan sandi</button>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/auth/broker.blade.php ENDPATH**/ ?>