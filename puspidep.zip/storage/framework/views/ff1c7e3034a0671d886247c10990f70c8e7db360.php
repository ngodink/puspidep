<?php $__env->startSection('content'); ?>
    <div class="container text-center mt-5 pt-5">
        <p><img src="<?php echo e(asset('img/undraw/empty.png')); ?>" alt="" class="w-100" style="max-width: 400px;"></p>
        <div class="display-4 font-weight-bold mb-2">
            <?php echo $__env->yieldContent('code'); ?>
        </div>
        <p class="text-muted"><?php echo $__env->yieldContent('message'); ?></p>
        <a class="btn btn-sm btn-dark rounded-pill px-3 mr-2" href="<?php echo e(url()->previous()); ?>">Kembali</a>
        <a class="btn btn-sm btn-outline-dark rounded-pill px-3" href="<?php echo e(config('app.url')); ?>">Halaman utama</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\resources\views/errors/default.blade.php ENDPATH**/ ?>