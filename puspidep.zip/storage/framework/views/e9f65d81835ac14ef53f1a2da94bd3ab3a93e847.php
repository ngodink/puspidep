<div class="list-group list-group-flush">
	<?php $__empty_1 = true; $__currentLoopData = $posts->load('categories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<a class="list-group-item list-group-item-action px-0 <?php if($loop->last): ?> border-bottom-0 <?php endif; ?> <?php if($loop->first): ?> border-top-0 <?php endif; ?>" style="border-top-style: dotted;" href="<?php echo e(route('web::read', ['category' => $post->category()->slug, 'slug' => $post->slug])); ?>">
			<span class="d-flex flex-row justify-content-between align-items-center">
				<i class="mdi mdi-chevron-right-circle-outline mr-2"></i>
				<div class="flex-grow-1">
					<div class="small">
						<?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<strong class="text-success"><?php echo e($category->name); ?></strong>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php echo e($post->title); ?>

				</div>
			</span>
		</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		Tidak ada postingan
	<?php endif; ?>
</div><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/includes/post-widgets-2.blade.php ENDPATH**/ ?>