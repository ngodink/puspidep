<?php $__env->startSection('title', $type->name.' - '); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 bg-white rounded">

	<div class="row">
		<div class="col-md-8">
			<h5 class="mb-5"><strong><?php echo e($type->name); ?> terbaru</strong></h5>
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<a class="text-dark" href="<?php echo e(route('web::read', ['type' => $type->slug, 'slug' => $post->slug])); ?>">
					<div class="d-sm-flex flex-row filtered align-items-center">
						<div class="mr-sm-4">
							<div class="filtered-img mb-3 mb-sm-0 rounded" style="background: url(<?php echo e(asset('storage/'.$post->img)); ?>) center center no-repeat; background-size: cover; min-width: 200px; height: 200px;"></div>
						</div>
						<div class="my-3">
							<div class="d-flex flex-row align-items-center">
								<img class="rounded-circle mr-3" src="<?php echo e($post->author ? $post->author->profile->avatar_path : asset('img/default-avatar.svg')); ?>" alt="" style="width: 46px">
								<div>
									<div class="font-weight-bold"><?php echo e($post->author->profile->name ?? 'Penulis'); ?></div>
									<div class="text-muted small"><?php echo e($post->published_at->ISOFormat('LL')); ?></div>
								</div>
							</div>
							<h5 class="mt-3"><strong><?php echo e($post->title); ?></strong></h5>
							<div class="text-muted mb-2 mb-lg-4"><?php echo e(\Str::words(strip_tags($post->content), 12)); ?></div>
							<a href="<?php echo e(route('web::read', ['type' => $type->slug, 'slug' => $post->slug])); ?>">Selengkapnya &raquo;</a>
						</div>
					</div>
				</a>
				<?php if($loop->last): ?>
					<br><br>
					<?php echo e($posts->links()); ?>

				<?php else: ?>
					<hr class="my-4 my-sm-5">
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				Tidak ada <?php echo e(strtolower($type->name)); ?>

			<?php endif; ?>
		</div>
		<div class="col-md-4 mt-5 mt-sm-0">
			<h5 class="mb-5"><strong>Latest Blog</strong></h5>
			<div class="bg-light mb-4 rounded" style="height: 250px;"></div>
			<hr class="my-4 my-sm-5">
			<h5 class="mb-5"><strong>Latest Portofolio</strong></h5>
			<div class="bg-light mb-4 rounded" style="height: 400px;"></div>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/type.blade.php ENDPATH**/ ?>