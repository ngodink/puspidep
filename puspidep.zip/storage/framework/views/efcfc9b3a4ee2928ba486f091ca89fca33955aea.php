<div id="post-carousel" class="carousel slide carousel-fade mb-5" data-ride="carousel">
	<ol class="carousel-indicators">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li data-target="#post-carousel" data-slide-to="<?php echo e($loop->index); ?>" <?php if($loop->first): ?> class="active" <?php endif; ?>></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ol>
	<div class="carousel-inner rounded">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
				<div class="black-overlay" style="<?php if($post->img): ?> background: url(<?php echo e(Storage::url($post->img)); ?>) center center no-repeat; background-size: cover; <?php else: ?> background-color: #3a3b45; <?php endif; ?> height: 400px;"></div>
				<div class="carousel-caption mb-2">
					<h5><strong><?php echo e($post->title); ?></strong></h5>
					<p>
						<i class="mdi mdi-eye"></i> <small><?php echo e($post->views_count); ?></small>
						
						<i class="mdi <?php echo e($post->commentable ? 'mdi-comment' : 'mdi-comment-remove'); ?>"></i> <small><?php echo e($post->comments_count); ?></small>
						<i class="mdi mdi-calendar"></i> <small><?php echo e($post->created_at ? $post->created_at->ISOFormat('L') : '-'); ?></small>
					</p>
					<a class="btn btn-light rounded-pill btn-sm px-3" href="<?php echo e(route('web::read', ['category' => $post->category()->slug, 'slug' => $post->slug])); ?>">Selengkapnya &raquo;</a>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<a class="carousel-control-prev" href="#post-carousel" role="button" data-slide="prev">
		<span class="mdi mdi-chevron-left-circle-outline h2"></span>
	</a>
	<a class="carousel-control-next" href="#post-carousel" role="button" data-slide="next">
		<span class="mdi mdi-chevron-right-circle-outline h2"></span>
	</a>
</div>
<?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/includes/post-widgets-4.blade.php ENDPATH**/ ?>