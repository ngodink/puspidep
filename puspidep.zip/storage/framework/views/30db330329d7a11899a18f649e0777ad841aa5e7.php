<div class="row">
    <div class="col-md-6 mb-3 mb-md-0">
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">Menampilkan</div>
            </div>
            <select class="form-control w-25" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                <?php $__currentLoopData = [5, 10, 25, 50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(url()->current()); ?>?<?php echo e(http_build_query(array_merge(request()->except('page'), ['limit' => $limiter]))); ?>" <?php if(request('limit', 10) == $limiter): ?> selected <?php endif; ?>><?php echo e($limiter); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="input-group-append">
                <div class="input-group-text">baris</div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <?php if($paginator->hasPages()): ?>
            <div class="input-group">
                <div class="input-group-prepend">
                    <a class="input-group-btn btn btn-outline-secondary <?php echo e(request('page') <= 1 ? 'disabled' : 'text-success'); ?>" style="font-size:12pt; line-height: 1.3rem;" href="<?php echo e($paginator->url(1)); ?>">&laquo;</a>
                    <a class="input-group-btn btn btn-outline-secondary <?php echo e(request('page') <= 1 ? 'disabled' : 'text-success'); ?>" style="font-size:12pt; line-height: 1.3rem;" href="<?php echo e($paginator->previousPageUrl()); ?>">&lsaquo;</a>
                    <div class="input-group-text">Halaman</div>
                </div>
                <select class="form-control w-25" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                    <?php for($page = 1; $page <= $paginator->lastPage(); $page++): ?>
                    <option value="<?php echo e($paginator->url($page)); ?>" <?php if(request('page') == $page): ?> selected <?php endif; ?>><?php echo e($page); ?></option>
                    <?php endfor; ?>
                </select>
                <div class="input-group-append">
                    <a class="input-group-btn btn btn-outline-secondary <?php echo e(request('page') >= $paginator->lastPage() ? 'disabled' : 'text-success'); ?>" style="font-size:12pt; line-height: 1.3rem;" href="<?php echo e($paginator->nextPageUrl()); ?>">&rsaquo;</a>
                    <a class="input-group-btn btn btn-outline-secondary <?php echo e(request('page') >= $paginator->lastPage() ? 'disabled' : 'text-success'); ?>" style="font-size:12pt; line-height: 1.3rem;" href="<?php echo e($paginator->url($paginator->lastPage())); ?>">&raquo;</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\puspidep\resources\views/vendor/pagination/bootstrap-4.blade.php ENDPATH**/ ?>