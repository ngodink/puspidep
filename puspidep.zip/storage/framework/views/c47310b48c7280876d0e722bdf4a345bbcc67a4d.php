<?php $__env->startSection('titleTemplate', config('app.name').' - Pusat Pengkajian Islam Demokrasi dan Perdamaian'); ?>

<?php $__env->startSection('bodyclass', 'min-vh-100 d-flex flex-column justify-content-between bg-light'); ?>

<?php $__env->startSection('main'); ?>
	<div>
	    <?php echo $__env->make('web::layouts.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    <div id="app" class="page-fade">
	        <main>
	            <?php echo $__env->yieldContent('content'); ?>
	        </main>
	    </div>
    	<?php echo $__env->make('account::auth.includes.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
    <?php echo $__env->make('web::layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/layouts/default.blade.php ENDPATH**/ ?>