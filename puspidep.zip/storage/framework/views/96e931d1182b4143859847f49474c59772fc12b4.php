<nav class="bg-light py-3 px-0 mt-5">
	<div class="container">
		<div class="row text-muted">
			<div class="col-sm-6 text-center text-sm-left">
				Copyright © 2020
			</div>
			<div class="col-sm-6 text-center text-sm-right">
				All rights reserved to <?php echo e(config('app.name')); ?>

			</div>
		</div>
	</div>
</nav><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/layouts/includes/footer.blade.php ENDPATH**/ ?>