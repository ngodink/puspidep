<?php $__env->startSection('title', 'Email terverifikasi - '); ?>

<?php $__env->startSection('content'); ?>
	<h2>Email terverifikasi</h2>
	<p>Terimakasih telah memverifikasi alamat e-mail Anda <?php echo e($email->address); ?></p>
	<button class="btn btn-warning" style="border: none;" onclick="window.close()">Tutup halaman ini</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/user/email/verified.blade.php ENDPATH**/ ?>