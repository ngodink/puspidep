<?php $__env->startSection('title', 'Beranda - '); ?>

<?php ($last = $members->last()); ?>
<?php ($creator = $user->institution()->exists()); ?>

<?php $__env->startSection('content'); ?>
	<div class="p-md-5">
		<div class="row text-center text-lg-left d-flex mb-4">
			<div class="col-lg-auto">
				<img class="rounded-circle shadow mb-4 mb-lg-0" src="<?php echo e(asset('img/default-avatar.svg')); ?>" alt="" width="80">
			</div>
			<div class="col-lg-auto align-self-center">
			    <h3 class="mb-1">Selamat datang kembali, <?php echo e(auth()->user()->profile->full_name); ?>!</h3>
			    <p class="text-muted mb-0">di situs keanggotaan <?php echo e(config('app.name')); ?></p>
			</div>
		</div>

		<?php if(!$last->verified_at): ?>
			<div class="card-header alert alert-danger alert-dismissible fade show border-0 rounded-0" role="alert">
				<strong>Perhatian!</strong> <?php echo e(!$last->institution_id || $creator ? 'Anda' : 'Pembuat lembaga'); ?> belum mengupload bukti transfer, status keanggotaan individu Anda belum aktif!
				<button type="button" class="close" data-dismiss="alert"> <span>&times;</span> </button>
			</div>
		<?php endif; ?>

		<div class="row">
			<div class="col-lg-8">

				<?php if(!$last->verified_at && ($creator || !$last->institution_id)): ?>
					<div class="card mb-4">
						<div class="card-header bg-white">
							<i class="mdi mdi-cloud-upload-outline"></i> <strong>Upload bukti transfer</strong>
						</div>
						<div class="card-body">
							<?php if(!$last->verified_at): ?>
								<form action="<?php echo e(route('member::upload', ['member' => $last->id])); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
									<div class="border rounded text-center mb-3">
										<img id="upload-preview" class="img-fluid" src="<?php echo e(asset('img/no-image.png')); ?>" alt="" style="max-height: 224px;">
									</div>
									<div class="alert alert-info">
									    <strong>Petunjuk Pengunggahan</strong>
									    <small>
									        <ul class="pl-3 mb-0">
									            <li>Berkas yang akan diunggah adalah benar-benar berkas asli.</li>
									            <li>Maksimal ukuran berkas adalah 1024kb atau 1mb</li>
									            <li>Ekstensi berkas yang diperbolehkan adalah jpeg, jpg, dan png</li>
									        </ul>
									    </small>
									</div>
									<div class="form-group required mb-0">
										<div class="input-group">
											<div class="custom-file">
												<input type="file" name="file" class="custom-file-input" id="upload-input" required accept="image/*">
												<label class="custom-file-label" for="upload-input">Pilih berkas ...</label>
											</div>
											<div class="input-group-append">
												<button class="btn btn-warning"><i class="mdi mdi-send-circle-outline mdi-rotate-315"></i> Upload</button>
											</div>
										</div>
										<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<small class="text-danger"> <?php echo e($message); ?> </small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</form>
							<?php else: ?>
								<p>Anda telah mengirimkan bukti transfer, silahkan tunggu dalam 1-2 hari untuk proses verifikasi dari tim kami, terimakasih!</p>
								<p class="text-muted mb-0">Jika dalam waktu tersebut belum ada pemberitahuan via e-mail, silahkan hubungi kami <a href="#">di sini</a></p>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
				<div class="card mb-4">
					<div class="card-header bg-white">
						<i class="mdi mdi-account-circle-outline"></i> <strong>Profil Anda</strong>
					</div>
					<div class="list-group list-group-flush">
						<?php $__currentLoopData = [
							'Nama lengkap' => $user->profile->full_name,
							'Tempat lahir' => $user->profile->pob,
							'Tanggal lahir' => $user->profile->dob_name,
							'Jenis kelamin' => $user->profile->sex_name,
						]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a class="list-group-item list-group-item-action border-0" href="<?php echo e(route('account::user.profile', ['next' => url()->current()])); ?>">
								<div class="row">
									<div class="col-10">
										<div class="row">
											<div class="col-md-4">
												<small><?php echo e($k); ?></small>
											</div>
											<div class="col-md-8">
												<span class="<?php echo e($v ? 'font-weight-bold text-gray-800' : 'text-muted'); ?>">
													<?php echo e($v ?? 'Belum diisi'); ?>

												</span>
											</div>
										</div>
									</div>
									<div class="col-2 text-right align-self-center">
										<i class="mdi mdi-chevron-right"></i>
									</div>
								</div>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="card-footer text-muted bg-white">
						<small>Beberapa info mungkin terlihat oleh orang lain</small>
					</div>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="card mb-4">
					<div class="card-header bg-white">
						<i class="mdi mdi-account-child-outline"></i> <strong>Informasi keanggotaan</strong>
					</div>
					<div class="card-body py-3">
						<p>
							<small>Jenis keanggotaan</small> <br>
							<strong><?php echo e($last->special ? 'Kehormatan' : 'Individu'); ?></strong>
						</p>
						<p>
							<small>Status</small> <br>
							<?php if($last->verified_at): ?>
								<span class="badge badge-pill badge-success"><i class="mdi mdi-check-circle-outline"></i> Aktif</span>
							<?php else: ?>
								<span class="badge badge-pill badge-danger"><i class="mdi mdi-close-circle-outline"></i> Belum aktif</span>
							<?php endif; ?>
						</p>
						<p class="mb-0">
							<small>Nomor Anggota</small> <br>
							<?php if($last->verified_at): ?>
								<strong><?php echo e($last->kd); ?></strong>
							<?php else: ?>
								<span class="text-muted">Tidak ada</span>
							<?php endif; ?>
						</p>
					</div>
					<?php if($last->institution_id): ?>
						<div class="card-footer text-muted bg-white">
							<small><i class="mdi mdi-alert-circle"></i> Status keanggotaan Anda mengikuti status keanggotaan lembaga Anda </small>
						</div>
					<?php endif; ?>
				</div>
				<?php if(count($user->institutions)): ?>
					<?php ($institution = $user->institutions->last()); ?>
					<div class="card mb-4">
						<div class="card-header bg-white">
							<i class="mdi mdi-graph-outline"></i> <strong>Lembaga Anda</strong>
						</div>
						<div class="card-body">
							<?php $__currentLoopData = [
								'Nama lembaga' => $institution->name,
								'Alamat' => $institution->regional
							]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<p <?php if($loop->last): ?> class="mb-0" <?php endif; ?>>
									<small><?php echo e($k); ?></small>
									 <br>
									<span class="<?php echo e($v ? 'font-weight-bold text-gray-800' : 'text-muted'); ?>">
										<?php echo e($v ?? 'Belum diisi'); ?>

									</span>
								</p>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php if($creator): ?>
							<div class="card-footer text-muted bg-white">
								<small><i class="mdi mdi-alert-circle"></i> Anda adalah pemilik lembaga ini</small>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<div class="card mb-4">
					<div class="card-header bg-white">
						<i class="mdi mdi-link-variant"></i> <strong>Link cepat</strong>
					</div>
					<div class="list-group list-group-flush">
						<a class="list-group-item list-group-item-action text-warning" href="<?php echo e(route('account::index')); ?>"><i class="mdi mdi-account-circle-outline"></i> Profil saya</a>
						<a class="list-group-item list-group-item-action text-warning" href="<?php echo e(route('account::password', ['next' => url()->current()])); ?>"><i class="mdi mdi-logout"></i> Ubah password</a>
					</div>
				</div>
			</div>
		</div>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
	$(function () {
		function readURL(input) {
			if (input.files && input.files[0]) {
				$('[for="upload-input"]').html(input.files[0].name)
				var reader = new FileReader();
				reader.onload = function(e) {
					$('#upload-preview').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}

		$("#upload-input").change(function(e) {
			readURL(this);
		});
	})
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('member::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Member\Resources/views/index.blade.php ENDPATH**/ ?>