<ul class="navbar-nav bg-gradient-warning sidebar sidebar-dark accordion" id="accordionSidebar">
	<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
		<div class="sidebar-brand-icon">
			<img src="<?php echo e(asset('img/logo/rounded-bw-32.png')); ?>" alt="" width="24">
		</div>
		<div class="sidebar-brand-text mx-2">AIAT</div>
	</a>
	<hr class="sidebar-divider my-0">
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('member::index')); ?>">
			<i class="mdi mdi-home-outline"> </i> <span> Beranda </span>
		</a>
	</li>
	
	<hr class="sidebar-divider">
	<div class="sidebar-heading"> Akun saya </div>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('account::index')); ?>">
			<i class="mdi mdi-account-circle-outline"> </i> <span> Profil </span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('account::password', ['next' => url()->current()])); ?>">
			<i class="mdi mdi-lock-outline"> </i> <span> Ubah password </span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo e(route('account::auth.logout')); ?>" onclick="event.preventDefault(); $('#logout-form').submit();">
			<i class="mdi mdi-logout"> </i> <span> Logout </span>
		</a>
	</li>
	<hr class="sidebar-divider d-none d-md-block">
	<div class="text-center d-none d-md-inline">
		<button class="rounded-circle border-0" id="sidebarToggle">
		</button>
	</div>
</hr>
</hr>
</hr>
</hr>
</ul><?php /**PATH C:\laragon\www\aiat\modules/Member\Resources/views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>