<?php $__env->startSection('title', 'Lupa sandi -'); ?>

<?php $__env->startSection('content'); ?>
	<h2>Lupa sandi</h2>
	<p class="text-muted mb-4">Kami akan mengirimkan tautan pemulihan sandi ke e-mail Anda</p>
	<form class="form-block" action="<?php echo e(route('account::auth.forgot')); ?>" method="POST"> <?php echo csrf_field(); ?>
		<div class="form-group">
			<input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Alamat e-mail" value="<?php echo e(old('email')); ?>" required autofocus>
			<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="invalid-feedback"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class="form-group mb-0 mt-5">
			<button type="submit" class="btn btn-warning px-3">Kirim tautan</button>
			<a class="btn btn-secondary" href="<?php echo e(route('account::auth.login')); ?>">Kembali</a>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('account::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aiat\modules/Account\Resources/views/auth/forgot.blade.php ENDPATH**/ ?>