<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>
				Copyright &copy; 2020
			</span>
		</div>
	</div>
</footer><?php /**PATH C:\laragon\www\aiat\modules/Member\Resources/views/layouts/includes/footer.blade.php ENDPATH**/ ?>