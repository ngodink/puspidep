<div class="row no-gutters mb-4">
	<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<?php if($post->img): ?>
			<a class="col-6 p-1 text-dark mb-2" href="<?php echo e(route('web::read', ['category' => $post->category()->slug, 'slug' => $post->slug])); ?>">
				<img class="img-fluid rounded" src="<?php echo e(Storage::url($post->img)); ?>" alt="">
				<?php echo e($post->title); ?>

			</a>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		Tidak ada postingan
	<?php endif; ?>
</div><?php /**PATH C:\laragon\www\puspidep\modules/Web\Resources/views/includes/post-widgets-3.blade.php ENDPATH**/ ?>